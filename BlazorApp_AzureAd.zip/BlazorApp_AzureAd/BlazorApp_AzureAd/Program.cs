using BlazorApp_AzureAd.Components;
using BlazorApp_AzureAd.Components.Auth;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.UI;

var builder = WebApplication.CreateBuilder(args);

// Add authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
})
.AddMicrosoftIdentityWebApp(options => {
    builder.Configuration.Bind("AzureAd", options);
    options.Instance = "https://login.microsoftonline.com/";
    options.SignedOutCallbackPath = "/login";
    options.SignOutScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.UseTokenLifetime = true;
    options.ClientSecret = builder.Configuration["AzureAd:ClientSecret"];
});

// Add authorization
builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = options.DefaultPolicy;
});

// Add authentication state provider
builder.Services.AddScoped<AuthenticationStateProvider, AzureAdAuthenticationStateProvider>();
builder.Services.AddAuthorizationCore();

// Add HttpContextAccessor
builder.Services.AddHttpContextAccessor();

// Add MVC services
builder.Services.AddControllers();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

// Add authentication middleware
app.UseAuthentication();
app.UseAuthorization();

// Map controllers
app.MapControllers();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
