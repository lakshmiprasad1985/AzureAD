# Blazor App with Azure AD Authentication

This is a Blazor Server application that demonstrates Azure AD authentication integration. The application includes features like user authentication, file reading, and role-based access control.

## Table of Contents
- [Prerequisites](#prerequisites)
- [Setup Instructions](#setup-instructions)
- [Azure AD Configuration](#azure-ad-configuration)
- [Program.cs Explained](#programcs-explained)
- [Authentication Flow](#authentication-flow)
- [Features](#features)
- [Troubleshooting](#troubleshooting)

## Prerequisites

- .NET 8.0 SDK or later
- Visual Studio 2022 or later
- Azure subscription
- Azure AD tenant

## Setup Instructions

1. **Clone the Repository**
   ```bash
   git clone [repository-url]
   cd BlazorApp_AzureAd
   ```

2. **Install Dependencies**
   ```bash
   dotnet restore
   ```

3. **Configure Azure AD**
   - Follow the [Azure AD Configuration](#azure-ad-configuration) section
   - Update appsettings.json with your Azure AD details

4. **Run the Application**
   ```bash
   dotnet run
   ```

## Azure AD Configuration

1. **Register Application in Azure AD**
   - Go to Azure Portal (https://portal.azure.com)
   - Navigate to Azure Active Directory
   - Select "App registrations"
   - Click "New registration"
   - Enter application name
   - Select supported account types
   - Click "Register"

2. **Configure Authentication**
   - In your app registration, go to "Authentication"
   - Add platform: Web
   - Set redirect URI: https://localhost:xxxx/signin-oidc
   - Enable ID tokens
   - Click "Save"

3. **Create Client Secret**
   - Go to "Certificates & secrets"
   - Click "New client secret"
   - Add description and expiration
   - Copy the secret value

4. **Update appsettings.json**
   ```json
   {
     "AzureAd": {
       "Instance": "https://login.microsoftonline.com/",
       "Domain": "your-domain.onmicrosoft.com",
       "TenantId": "your-tenant-id",
       "ClientId": "your-client-id",
       "ClientSecret": "your-client-secret",
       "CallbackPath": "/signin-oidc",
       "SignedOutCallbackPath": "/login"
     }
   }
   ```

## Program.cs Explained

The Program.cs file is the entry point of the application and configures all the necessary services and middleware. Here's a detailed breakdown:

### 1. Service Configuration
```csharp
// Add authentication
builder.Services.AddAuthentication(options =>
{
    // Set default authentication scheme to Cookies
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    // Set default challenge scheme to OpenIdConnect (Azure AD)
    options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
})
.AddMicrosoftIdentityWebApp(options => {
    // Bind Azure AD settings from appsettings.json
    builder.Configuration.Bind("AzureAd", options);
    // Set Azure AD instance URL
    options.Instance = "https://login.microsoftonline.com/";
    // Set callback path after logout
    options.SignedOutCallbackPath = "/login";
    // Set sign-out scheme to use cookies
    options.SignOutScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    // Use token lifetime for session management
    options.UseTokenLifetime = true;
    // Set client secret for authentication
    options.ClientSecret = builder.Configuration["AzureAd:ClientSecret"];
});
```

### 2. Authorization Configuration
```csharp
// Add authorization with default policy
builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = options.DefaultPolicy;
});
```

### 3. Authentication State Provider
```csharp
// Add custom authentication state provider
builder.Services.AddScoped<AuthenticationStateProvider, AzureAdAuthenticationStateProvider>();
// Add authorization core services
builder.Services.AddAuthorizationCore();
```

### 4. HTTP Context Access
```csharp
// Add HTTP context accessor for accessing HttpContext
builder.Services.AddHttpContextAccessor();
```

### 5. MVC Services
```csharp
// Add MVC services for controller support
builder.Services.AddControllers();
```

### 6. Middleware Configuration
```csharp
// Add authentication middleware
app.UseAuthentication();
// Add authorization middleware
app.UseAuthorization();
// Map controller endpoints
app.MapControllers();
```

### Authentication and Authorization Flow

1. **Authentication Setup**
   - Cookie authentication is set as the default scheme
   - OpenIdConnect is used for challenges (login)
   - Microsoft Identity Web handles Azure AD integration

2. **Authorization Configuration**
   - Default policy is set as fallback
   - Custom policies can be added for specific requirements
   - Role-based access control is supported

3. **Middleware Pipeline**
   - Authentication middleware processes requests first
   - Authorization middleware checks permissions
   - Controllers are mapped for API endpoints

4. **State Management**
   - AuthenticationStateProvider manages user state
   - HttpContextAccessor provides request context
   - Cookie authentication maintains session

## Authentication Flow

1. **Login Process**
   - User clicks Login button
   - Redirected to Azure AD login page
   - User enters credentials
   - Azure AD validates and returns token
   - Application creates authentication cookie

2. **Session Management**
   - Cookie maintains user session
   - Token lifetime controls session duration
   - Authentication state provider manages user state

3. **Logout Process**
   - User clicks Logout
   - Application clears authentication cookie
   - Redirects to Azure AD logout
   - Returns to login page

## Features

1. **User Authentication**
   - Azure AD integration
   - Secure login/logout
   - Session management

2. **File Reader**
   - Protected file reading functionality
   - File content display
   - Error handling

3. **Role-Based Access**
   - User role management
   - Protected routes
   - Authorization policies

## Troubleshooting

1. **Authentication Issues**
   - Verify Azure AD configuration
   - Check redirect URIs
   - Ensure client secret is correct

2. **File Reader Issues**
   - Check file size limits
   - Verify file permissions
   - Check error messages

3. **Common Errors**
   - "Scheme already exists": Remove duplicate authentication configuration
   - "Invalid client secret": Verify secret in appsettings.json
   - "Redirect URI mismatch": Check Azure AD configuration

## Help Notes

1. **Development Tips**
   - Use user secrets for sensitive data
   - Enable detailed error messages in development
   - Use browser dev tools for debugging

2. **Security Best Practices**
   - Never commit secrets to source control
   - Use HTTPS in production
   - Implement proper error handling

3. **Testing**
   - Test with multiple user accounts
   - Verify role-based access
   - Check logout functionality

## Additional Resources

- [Azure AD Documentation](https://docs.microsoft.com/en-us/azure/active-directory/)
- [Blazor Documentation](https://docs.microsoft.com/en-us/aspnet/core/blazor/)
- [Microsoft Identity Web](https://github.com/AzureAD/microsoft-identity-web)

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review Azure AD documentation
3. Contact support team

## License

This project is licensed under the MIT License - see the LICENSE file for details. 